function SpawnPlayer()
    local player  = source 
	spawnPlayer(source,2484.000, -1670.000, 13.336)
	setElementModel(source,59)
	fadeCamera(source, true)
	setCameraTarget(source, source)
end
addEventHandler("onPlayerJoin", root, SpawnPlayer)