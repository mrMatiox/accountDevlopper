
local hospitalPosition = { x = 1179.83, y = -1324.28, z = 14.15 }


local maxHealth = 100


local playerSkins = {}


function savePlayerSkin(player)
    local skin = getElementModel(player)
    playerSkins[player] = skin
end

function restorePlayerSkin(player)
    local skin = playerSkins[player]
    if skin then
        setElementModel(player, skin)
    end
end

function transportToHospital(player)
    if isElement(player) then

        savePlayerSkin(player)

        setElementPosition(player, hospitalPosition.x, hospitalPosition.y, hospitalPosition.z)

        setTimer(function()

            setElementHealth(player, maxHealth)
            spawnPlayer(player, hospitalPosition.x, hospitalPosition.y, hospitalPosition.z) 

            restorePlayerSkin(player)
            
            outputChatBox("You Are Back ", player)
        end, 5000, 1)
    end
end

addEventHandler("onPlayerWasted", root, function()
    transportToHospital(source)
end)
