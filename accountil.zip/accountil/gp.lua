function getPos ( thePlayer )
	local x,y,z = getElementPosition( thePlayer )
	local dim = getElementDimension( thePlayer )
	local int = getElementInterior( thePlayer )
	outputChatBox ( "You are at: "..x..", "..y..", "..z.."", thePlayer ,255,144,51)
	outputChatBox ( "Dimension: "..dim.."", thePlayer , 255,144,51 )
	outputChatBox ( "Interior: "..int.."", thePlayer ,255,144,51)
end
addCommandHandler ("gp", getPos, thePlayer )